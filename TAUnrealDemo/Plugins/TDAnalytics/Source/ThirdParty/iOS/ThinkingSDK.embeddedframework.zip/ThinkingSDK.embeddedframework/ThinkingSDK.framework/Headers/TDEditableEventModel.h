
#if __has_include(<ThinkingSDK/TDUpdateEventModel.h>)
#import <ThinkingSDK/TDUpdateEventModel.h>
#else
#import "TDUpdateEventModel.h"
#endif

#if __has_include(<ThinkingSDK/TDOverwriteEventModel.h>)
#import <ThinkingSDK/TDOverwriteEventModel.h>
#else
#import "TDOverwriteEventModel.h"
#endif
