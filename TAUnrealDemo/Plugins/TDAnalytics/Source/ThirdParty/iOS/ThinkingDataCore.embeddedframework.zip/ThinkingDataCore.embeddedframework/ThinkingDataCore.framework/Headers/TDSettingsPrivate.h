//
//  TDSettingsPrivate.h
//  Pods
//
//  Created by 杨雄 on 2024/6/20.
//

#ifndef TDSettingsPrivate_h
#define TDSettingsPrivate_h

#import <Foundation/Foundation.h>

@interface TDSettings()

- (instancetype)initWithDictionary:(NSDictionary *)dict;

@end

#endif /* TDSettingsPrivate_h */
