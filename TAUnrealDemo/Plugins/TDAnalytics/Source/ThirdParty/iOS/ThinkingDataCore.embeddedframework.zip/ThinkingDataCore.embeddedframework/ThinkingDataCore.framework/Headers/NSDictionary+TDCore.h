//
//  NSDictionary+TDCore.h
//  Pods-DevelopProgram
//
//  Created by 杨雄 on 2024/3/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (TDCore)


@end

NS_ASSUME_NONNULL_END
