//
//  NSNumber+TDCore.h
//  Pods-DevelopProgram
//
//  Created by 杨雄 on 2024/7/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSNumber (TDCore)

- (BOOL)td_isBool;

@end

NS_ASSUME_NONNULL_END
