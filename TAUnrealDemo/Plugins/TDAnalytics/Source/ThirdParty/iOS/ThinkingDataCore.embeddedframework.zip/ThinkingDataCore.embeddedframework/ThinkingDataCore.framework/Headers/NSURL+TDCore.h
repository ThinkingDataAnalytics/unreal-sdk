//
//  NSURL+TDCore.h
//  Pods-DevelopProgram
//
//  Created by 杨雄 on 2024/5/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSURL (TDCore)

+ (NSString *)td_baseUrlStringWithString:(NSString *)urlString;

@end

NS_ASSUME_NONNULL_END
